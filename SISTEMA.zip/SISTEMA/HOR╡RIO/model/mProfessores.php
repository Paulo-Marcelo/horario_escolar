<?php
class mProfessores {
	private $id;
	private $nome;
	private $sobrenome;
	private $email;
	private $senha;
	private $telefone;
	private $cpf;
	private $nascimento;
	private $atuacao;
	private $folgas;


	public function __construct($id, $nome, $sobrenome, $email, $senha, $telefone, $cpf, $nascimento, $atuacao, $folgas){
		$this->id = $id;
		$this->nome = $nome;
		$this->sobrenome = $sobrenome;
		$this->email = $email;
		$this->senha = $senha;
		$this->telefone = $telefone;
		$this->cpf = $cpf;
		$this->nascimento = $nascimento;
		$this->atuacao = $atuacao;
		$this->folgas = $folgas;
	}
	
	//GETTER'S'
	public function getId(){
		return $this->id;
	}

	public function getNome() {
		return $this->nome;
	}

	public function getSobrenome(){
		return $this->sobrenome;
	}

	public function getEmail(){
		return $this->email;
	}

	public function getSenha(){
		return $this->senha;
	}

	public function getTelefone(){
		return $this->telefone;
	}

	public function getCPF(){
		return $this->cpf;
	}

	public function getNasc(){
		return $this->nascimento;
	}

	public function getatuacao(){
		return $this->atuacao;
	}

	public function getFolgas(){
		return $this->folgas;
	}

	//SETTER'S
	public function setId($id) {
		$this->id = $id;
	}

	public function setNome($nome) {
		$this->nome = $nome;
	}

	public function setSobrenome($sobrenome) {
		$this->sobrenome = $sobrenome;
	}

	public function setEmail($email) {
		$this->email = $email;
	}

	public function setSenha($senha) {
		$this->senha = $senha;
	}

	public function setTelefone($telefone) {
		$this->telefone = $telefone;
	}

	public function setCPF($cpf){
		$this->cpf = $cpf;
	}

	public function setNasc($nascimento){
		$this->nascimento = $nascimento;
	}

	public function setatuacao($atuacao){
		$this->atuacao = $atuacao;
	}

	public function setFolgas($folgas){
		$this->folgas = $folgas;
	}
}
?>
