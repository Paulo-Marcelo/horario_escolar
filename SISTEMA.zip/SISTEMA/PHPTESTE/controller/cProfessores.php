<?php
require_once("../model/mProfessores.php");
require_once("../model/conexao.php");
class cProfessores {
	private $professores;

	public function __construct() {
		$this->professores = new mProfessores(null, null, null, null, null, null, null, null, null, null); 
	}

	public function Inserir($nome, $sobrenome, $email, $senha, $telefone, $cpf, $nascimento, $atuacao, $folgas) {
		$con = new conexao();
		$this->professores->setNome($nome);
		$this->professores->setSobrenome($sobrenome);
		$this->professores->setEmail($email);
		$this->professores->setSenha($senha);
		$this->professores->setTelefone($telefone);
		$this->professores->setCPF($cpf);
		$this->professores->setNasc($nascimento);
		$this->professores->setAtuacao($atuacao);
		$this->professores->setFolgas($folgas);
		$query = "INSERT INTO tb_professor(`professor_nome`, `professor_sobrenome`,`professor_email`,  `professor_senha`,`professor_telefone`, `professor_cpf`,`professor_nasc`, `professor_atuacao`,`professor_folga`) VALUES ('".$this->professores->getNome()."',
		'".$this->professores->getSobrenome()."',  '".$this->professores->getEmail()."', '".$this->professores->getSenha()."', '".$this->professores->getTelefone()."', '".$this->professores->getCPF()."', '".$this->professores->getNasc()."', '".$this->professores->getAtuacao()."', '".$this->professores->getFolgas()."')";

		$con->executar($query);
		$con->desconectar();
		header("Location: cadastro.php");
	}

	public function Pesquisar($nome) {
		$con = new conexao();
		if (isset($nome)) {
			$query = "Select * from tb_professor where professor_nome like '%$nome%'";
		} else {
			$query = "Select * from tb_professor";
		}
		$sql = $con->executar($query);
		$con->desconectar();
		return $sql;
	}
	
	public function deletarPro($id){
        $con = new conexao();
        $this->professores->setId($id);
        $query = "DELETE FROM `tb_professores` WHERE pro_id = ('".$this->professores->getId() ."')";
        $sql = $con->executar($query);
        $con->desconectar();
        return $sql;
    }

	// public function MostrarMateriasProfessores() {
	// 	$con = new conexao();
	// 	$query = "SELECT tb_materia.materia_id, tb_materia.materia_nome, tb_professor.professor_id, tb_professor.professor_nome FROM `tb_materia_has_tb_professor` INNER JOIN tb_materia ON tb_materia_meteria_id = tb_materia.materia_id INNER JOIN tb_professor ON tb_professor_professor_id = tb_professor.professor_id";
	// 	$sql = $con->executar($query);
	// 	$con->desconectar();
	// 	return $sql;
	// }

	public function MostrarProfessores() {
		$con = new conexao();
		$query = "SELECT * FROM tb_professor ORDER BY professor_nome ASC";
		$sql = $con->executar($query);
		$con->desconectar();
		return $sql;
	}

	public function MostrarMateria() {
		$con = new conexao();
		$query = "SELECT * FROM tb_materia";
		$sql = $con->executar($query);
		$con->desconectar();
		return $sql;
	}
}
?>