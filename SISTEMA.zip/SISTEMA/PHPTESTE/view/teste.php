<!DOCTYPE html>
<html>
<head>
	<title>teste</title>
    <meta charset="utf-8">
    <style type="text/css">
    	select{
    		outline: 0;
    	}
    	body{
		    height: 10em;
		    margin: 0;
		    position: absolute;
		    top: 20%;
		    left: 50%;
		    margin-right: -50%;
		    transform: translate(-50%, -50%);
    	}
    </style>
</head>
<body>
	<?php 
    	require_once("../controller/cProfessores.php");
    	$cMaterias = new cProfessores();
    	$sql = $cMaterias->MostrarProfessores();
    ?>
    <h3>SEGUNDA - FEIRA</h3>
	<form method="POST" action="#">
		<table id='tabela'>
	        <tr id="aula">
	        		<?php
		        		$dados = array();
		        		 while ($dad = mysqli_fetch_assoc($sql)) {
							$dados[] = $dad;
						}
		        		$sala = 1;
		        		$aula = 1;
		        		$id = 1;
		        		while ($sala <= 12) {
	        		 		if ($sala == 1) {
	        		 			echo "<tr><td>";
	        		 		}
		        			echo "<select onchange='onchange('$sala', '$aula','$id')' id='$id'>
								<option value='0'>Selecione...</option> ";
							foreach ($dados as $key) {
								echo "<option value=".$key['professor_id']."> ".$key['professor_nome']."</option>";
							}
						    echo "</select>"."  &nbsp;&nbsp;  ";
							$sala++;
							$id++;
							if ($sala == 13) {
								$sala = 1;
								echo "</td></tr>";
								$aula++;
							}
							if ($aula == 10) {	
								$sala = 13;
							}
						}	
					?>
	        </tr>
		</table>
	</form>

	<h3>TERÇA - FEIRA</h3>
	<form method="POST" action="#">
		<table id='tabela'>
	        <tr id="aula">
	        		<?php
		        		$dados = array();
		        		 while ($dad = mysqli_fetch_assoc($sql)) {
							$dados[] = $dad;
						}
		        		$sala = 1;
		        		$aula = 1;
		        		$id = 1;
		        		while ($sala <= 12) {
	        		 		if ($sala == 1) {
	        		 			echo "<tr><td>";
	        		 		}
		        			echo "<select onchange='onchange('$sala', '$aula','$id')' id='$id'>
								<option value='0'>Selecione...</option> ";
							foreach ($dados as $key) {
								echo "<option value=".$key['professor_id']."> ".$key['professor_nome']."</option>";
							}
						    echo "</select>"."  &nbsp;&nbsp;  ";
							$sala++;
							$id++;
							if ($sala == 13) {
								$sala = 1;
								echo "</td></tr>";
								$aula++;
							}
							if ($aula == 10) {	
								$sala = 13;
							}
						}	
					?>
	        </tr>
		</table>
	</form>

	<h3>QUARTA - FEIRA</h3>
	<form method="POST" action="#">
		<table id='tabela'>
	        <tr id="aula">
	        		<?php
		        		$dados = array();
		        		 while ($dad = mysqli_fetch_assoc($sql)) {
							$dados[] = $dad;
						}
		        		$sala = 1;
		        		$aula = 1;
		        		$id = 1;
		        		while ($sala <= 12) {
	        		 		if ($sala == 1) {
	        		 			echo "<tr><td>";
	        		 		}
		        			echo "<select onchange='onchange('$sala', '$aula','$id')' id='$id'>
								<option value='0'>Selecione...</option> ";
							foreach ($dados as $key) {
								echo "<option value=".$key['professor_id']."> ".$key['professor_nome']."</option>";
							}
						    echo "</select>"."  &nbsp;&nbsp;  ";
							$sala++;
							$id++;
							if ($sala == 13) {
								$sala = 1;
								echo "</td></tr>";
								$aula++;
							}
							if ($aula == 10) {	
								$sala = 13;
							}
						}	
					?>
	        </tr>
		</table>
	</form>

	<h3>QUINTA - FEIRA</h3>
	<form method="POST" action="#">
		<table id='tabela'>
	        <tr id="aula">
	        		<?php
		        		$dados = array();
		        		 while ($dad = mysqli_fetch_assoc($sql)) {
							$dados[] = $dad;
						}
		        		$sala = 1;
		        		$aula = 1;
		        		$id = 1;
		        		while ($sala <= 12) {
	        		 		if ($sala == 1) {
	        		 			echo "<tr><td>";
	        		 		}
		        			echo "<select onchange='onchange('$sala', '$aula','$id')' id='$id'>
								<option value='0'>Selecione...</option> ";
							foreach ($dados as $key) {
								echo "<option value=".$key['professor_id']."> ".$key['professor_nome']."</option>";
							}
						    echo "</select>"."  &nbsp;&nbsp;  ";
							$sala++;
							$id++;
							if ($sala == 13) {
								$sala = 1;
								echo "</td></tr>";
								$aula++;
							}
							if ($aula == 10) {	
								$sala = 13;
							}
						}	
					?>
	        </tr>
		</table>
	</form>

	<h3>SEXTA - FEIRA</h3>
	<form method="POST" action="#">
		<table id='tabela'>
	        <tr id="aula">
	        		<?php
		        		$dados = array();
		        		 while ($dad = mysqli_fetch_assoc($sql)) {
							$dados[] = $dad;
						}
		        		$sala = 1;
		        		$aula = 1;
		        		$id = 1;
		        		while ($sala <= 12) {
	        		 		if ($sala == 1) {
	        		 			echo "<tr><td>";
	        		 		}
		        			echo "<select onchange='onchange('$sala', '$aula','$id')' id='$id'>
								<option value='0'>Selecione...</option> ";
							foreach ($dados as $key) {
								echo "<option value=".$key['professor_id']."> ".$key['professor_nome']."</option>";
							}
						    echo "</select>"."  &nbsp;&nbsp;  ";
							$sala++;
							$id++;
							if ($sala == 13) {
								$sala = 1;
								echo "</td></tr>";
								$aula++;
							}
							if ($aula == 10) {	
								$sala = 13;
							}
						}	
					?>
	        </tr>
		</table>
	</form>
</body>
<script type="text/javascript">
	function choque(sala, aula, id){
		y = document.getElementById(id).value
		aula = document.getElementById(aula)
		y1 = document.getElementById(id)
		y1.style.background = "white"
		a = 1
		while(a <= 12){
			if(id != a){
				x = document.getElementById(a).value
				if(x == y){
					x2 = document.getElementById(a)
					x2.style.background = "red"
					y1.style.background = "red"
					aula.style.background = "red"
				}else{
					x2 = document.getElementById(a)
					x2.style.background = "white"
					y1.style.background = "white"
					aula.style.background = "white"
				}
			}
			a++
		}
	}
</script>
</html>