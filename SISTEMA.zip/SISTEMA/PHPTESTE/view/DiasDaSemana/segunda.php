<div id="DivLateral">
		<div id="DivA">
			<h3>1ª Aula<br><br>2ª Aula<br><br>3ª Aula<br><br>4ª Aula<br><br>5ª Aula<br><br>6ª Aula<br><br>7ª Aula<br><br>8ª Aula<br><br>9ª Aula</h3>
		</div>
		<div style='overflow-x:auto;'>
			<table class='bordered striped centered'>
				<tr>
					<td>1º <br>Enfermagem</td>
					<td>1º <br>Informática</td>
					<td>1º <br>Redes de Computadores</td>
					<td>1º <br>Administração</td>
					<td>2º <br>Enfermagem</td>
					<td>2º <br>Informática</td>
					<td>2º <br>Agropecuária</td>
					<td>2º <br>Finanças</td>
					<td>3º <br>Enfermagem</td>
					<td>3º <br>Redes de Computadores</td>
					<td>3º <br>Segurança do Trabalho</td>
					<td>3º <br>Informática</td>
				</tr>
					<tr>
						<?php 
		                	 require_once("../controller/cProfessores.php");
		                	 $cMaterias = new cProfessores();
		                	 $sql = $cMaterias->MostrarMateriasProfessores();
		                     while ($dados = mysqli_fetch_assoc($sql)) {
		                     	$id   = $dados['professor_id']   ."<br>".$dados['materia_id'];
		                        $nome = $dados['professor_nome'] ."<br>". $dados['materia_nome'];
		                        $materia[$id] = $nome;
		                     }
		                     $materias = shuffle($materia);	                    
		                     foreach ($materia as $materias){
		                     	echo "<td>".$materias."</td>";
		                     }

		                     
		                ?>
					</tr>
			</table>
		</div>
	</div>
	