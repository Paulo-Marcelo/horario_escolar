<!DOCTYPE html>
<html>
<head>
	<title>TESTANDO MATRIZ</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <meta charset="utf-8">

</head>
<body>
	<nav id="menu">
	    <ul>
	        <li><a href="index.php">Home</a></li>
	        <li><a href="turmas.php">Turmas</a></li>
	        <li><a href="cadastro.php">Cadastro</a></li>
	    </ul>
	</nav>

	<form method="GET" action="#">
		<p>*Selecione o dia que deseja inserir o horário*</p>
		<div  class="imobSelect">
			<select id="dias" name="dia">
				<option value="0">Selecione...</option>
				<option value="1">Segunda</option>
				<option value="2">Terça</option>
				<option value="3">Quarta</option>
				<option value="4">Quinta</option>
				<option value="5">Sexta</option>
			</select>
		</div>
		<input type="submit" value="Buscar" class="busc">
	</form><br><br><br>

	<?php
		if (isset($_GET['dia'])) {
			$DiaDaSemana = $_GET['dia'];
			if($DiaDaSemana == 1){
				require_once("DiasDaSemana/segunda.php");
			}
			if($DiaDaSemana == 2){
				require_once("DiasDaSemana/terça.php");
			}
			if($DiaDaSemana == 3){
				require_once("DiasDaSemana/quarta.php");
			}
			if($DiaDaSemana == 4){
				require_once("DiasDaSemana/quinta.php");
			}
			if($DiaDaSemana == 5){
				require_once("DiasDaSemana/sexta.php");
			}

		}
	?>
</body>
</html>